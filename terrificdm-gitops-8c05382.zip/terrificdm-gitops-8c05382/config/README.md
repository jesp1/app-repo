# GitOps app configuration files
This is GitOps demo app configuration repo(EKS+Jenkins+Flux)

