# GitOps app files
This is GitOps demo app repo(EKS+Jenkins+Flux)
